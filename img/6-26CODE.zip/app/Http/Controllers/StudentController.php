<?php

namespace App\Http\Controllers;

use DB;

use Illuminate\Http\Request;

class StudentController extends Controller
{
    public function show($id)
    {
        $name = "Daiben Angelo Sanchez";
        return view('students_show', compact('id', 'name'));
    }

    public function index()
    {
        $students = DB::select("SELECT first_name, last_name, province FRM students ORDER BY last_name LIMIT 20");
        $total_student = DB::select("SELECT COUNT(student_id) as total FROM students");
        $total_fem_student = DB::select("SELECT COUNT(student_id) as total_fem FROM students WHERE gender = 'female'");
        return view('students', compact('students', 'total_student', 'total_fem_student'));
    }
}