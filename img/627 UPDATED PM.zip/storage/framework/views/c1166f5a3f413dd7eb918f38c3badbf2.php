<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Subjects</title>
</head>
<body>
    <h1>Subjects</h1>
    <a class="btn btn-success" href="/subjects/create">Add new subject</a>
    <?php if(count($subjects) > 0): ?>
    <table class="table">
        <tr>
            <th>Subject ID</th>
            <th>Name</th>
            <th>Department</th>
            <th>View subject</th>
        </tr>
        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($s -> subject_id); ?></td>
            <td><?php echo e($s -> name); ?></td>
            <td><?php echo e($s -> department); ?></td>
            <td><a href="/subjects/<?php echo e($s -> subject_id); ?>">More info</a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
    </table>
    <?php else: ?>
    <p>No subjects found!</p>
    <?php endif; ?>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/subjects.blade.php ENDPATH**/ ?>