<footer>
     <p style="background-color: black; color: white">Copyright Daiben Angelo Sanchez | daibensanchez@company.com</p>
 </footer><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/layouts/footer.blade.php ENDPATH**/ ?>