<footer>
     <p style="background-color: black; color: white">Copyright Daiben Angelo Sanchez | daibensanchez@company.com</p>
 </footer>